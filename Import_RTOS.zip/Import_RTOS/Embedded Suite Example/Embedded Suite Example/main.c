/*
 * Embedded Suite Example.c
 *
 * Created: 7/3/2017 5:46:34 AM
 * Author : Brandon Segura
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

